import crypto from 'crypto';

// The secret key needs to be 32 bytes for aes-256-cbc.
// We should get this from the environment variables, with a fallback for local testing.
// In production, ENCRYPTION_KEY must be set to a secure 32-byte string.
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'default_secret_key_32_bytes_long_'; // Must be 32 characters
const IV_LENGTH = 16; // For AES, this is always 16

export function encrypt(text: string): string {
  if (!text) return text;
  try {
    // Basic check to see if we have a valid 32-byte key
    if (Buffer.from(ENCRYPTION_KEY).length !== 32) {
       console.warn('ENCRYPTION_KEY must be exactly 32 bytes long');
    }
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
  } catch (error) {
    console.error('Encryption failed:', error);
    throw new Error('Encryption failed');
  }
}

export function decrypt(text: string): string {
  if (!text) return text;
  // If text is not in the format iv:encrypted, it might be unencrypted legacy data.
  if (!text.includes(':')) return text;
  
  try {
    const textParts = text.split(':');
    const ivHex = textParts.shift();
    const encryptedTextHex = textParts.join(':');
    
    if (!ivHex || !encryptedTextHex) return text;
    
    const iv = Buffer.from(ivHex, 'hex');
    const encryptedText = Buffer.from(encryptedTextHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(ENCRYPTION_KEY), iv);
    
    let decrypted = decipher.update(encryptedText);
    decrypted = Buffer.concat([decrypted, decipher.final()]);
    
    return decrypted.toString();
  } catch (error) {
    console.error('Decryption failed:', error);
    return text; // Return the raw text if decryption fails, in case it was a plain string containing a colon
  }
}
